package tests;

public interface AI {
	public void execute();
	public void delete();
}
