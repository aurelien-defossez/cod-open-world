package tests;

public interface Game {
	public int callAPI(int parameter);
	public void delete();
}
